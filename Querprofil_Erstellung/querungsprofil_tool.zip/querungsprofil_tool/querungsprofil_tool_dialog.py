# -*- coding: utf-8 -*-
"""Querungsprofil tool: Dialog mit Profil, Bohrtrasse und Layout-Export."""
import os, tempfile
from datetime import datetime
import numpy as np
from qgis.core import *
from qgis.gui import QgsMapLayerComboBox, QgsVertexMarker, QgsMapTool, QgsRubberBand
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QDoubleSpinBox, QPushButton, QLineEdit, QSlider, QGroupBox, QGridLayout, QWidget, QRadioButton
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtXml import QDomDocument
try:
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as Canvas
except ImportError: # falls matplotlib in QGIS fehlt, für den Benutzer nachinstallieren
    import sys, subprocess, site
    subprocess.run([os.path.join(sys.exec_prefix, 'python.exe'), '-m', 'pip', 'install', '--user', 'matplotlib'], check=True)
    site.addsitedir(site.getusersitepackages())
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as Canvas
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter, MaxNLocator

FELD = 'querung_station' # Attribut im Linienlayer: Station des Querungspunkts (leer = automatisch Tiefpunkt)
VORLAGEN = {
    'A4': '08_Layouts/Querungsprofil_A4.qpt',
    'A3': '08_Layouts/Querungsprofil_A3.qpt',
} # Layout-Vorlagen je Format
GPKG = '02_Geopackage/querungen.gpkg' # relativ zum Projektordner, Ordner wird bei Bedarf angelegt
RUNDUNG = 20 # Profilmaßstäbe (Längen und Höhen) werden auf Vielfache davon aufgerundet
UEBERSICHT_RAND = 2.5 # Kartenbreite = Ausdehnung der Linie x UEBERSICHT_RAND (größer = weiter herausgezoomt)
GLAETTUNG = 5 # Modus 'Geländeparallel': Fensterbreite über die gemittelt wird


class LinienWerkzeug(QgsMapTool):
    """Linie in die Karte klicken: links Punkte setzen, rechts beenden."""
    def __init__(self, canvas, fertig):
        super().__init__(canvas); self.fertig, self.pts = fertig, []
        self.rb = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry); self.rb.setColor(QColor('red')); self.rb.setWidth(2)

    def canvasMoveEvent(self, e):
        if self.pts: self.rb.setToGeometry(QgsGeometry.fromPolylineXY(self.pts + [self.toMapCoordinates(e.pos())]), None)

    def canvasReleaseEvent(self, e):
        if e.button() == Qt.LeftButton: self.pts.append(self.toMapCoordinates(e.pos())); self.canvasMoveEvent(e)
        elif e.button() == Qt.RightButton and len(self.pts) > 1:
            g = QgsGeometry.fromPolylineXY(self.pts); self.pts = []; self.fertig(g)

    def deactivate(self):
        self.rb.reset(QgsWkbTypes.LineGeometry); self.pts = []; super().deactivate()


class ProfilDialog(QDialog):
    def __init__(self):
        super().__init__(iface.mainWindow())
        self.setWindowTitle('Querungsprofil')
        self.resize(1100, 700)
        self.d, self.z, self.s, self.out, self.drag = [], [], None, False, False
        self.line = self.geom = self.gez = None # Linienlayer (None = gezeichnete Linie), Liniengeometrie, gezeichnete Linie

        self.cl = self.combo('linie', QgsMapLayerProxyModel.LineLayer, 'gezeichnete Linie') # leerer Eintrag = gezeichnete Linie
        self.cd = self.combo('dgm', QgsMapLayerProxyModel.RasterLayer)
        self.mt, self.xt = self.spin('mt', 2.0), self.spin('xt', 6.0)
        self.hde, self.hda = self.spin('hd', 40.0), self.spin('hda', 40.0) # horizontale Distanz zum Eintritt / Austritt
        self.bw, self.rm = self.spin('bw', 6.0), self.spin('rm', 100.0)
        self.ae, self.aa = self.spin('ae', 12.0, '°'), self.spin('aa', 8.0, '°')
        self.te, self.ta = self.spin('te', 1.5), self.spin('ta', 1.5)
        self.nm = QLineEdit(); self.nm.setMinimumWidth(120); self.nm.textChanged.connect(self.plot) # Objektbezeichnung (wird nicht gespeichert)
        btn = QPushButton('Profil erstellen'); btn.clicked.connect(self.run)
        btn2 = QPushButton('Layout erstellen'); btn2.clicked.connect(self.export_layout)
        btn3 = QPushButton('Querung auf Tiefpunkt'); btn3.clicked.connect(self.auto_s)
        btn4 = QPushButton('Linie zeichnen'); btn4.clicked.connect(self.zeichnen)
        btn5 = QPushButton('Linie speichern'); btn5.clicked.connect(self.save_line)

        self.ks = list(VORLAGEN) # Layoutformat als Schiebeschalter: links erstes, rechts letztes Format
        self.fmt = QSlider(Qt.Horizontal); self.fmt.setRange(0, len(self.ks) - 1); self.fmt.setPageStep(1); self.fmt.setFixedWidth(40)
        f = QgsSettings().value('dgm_profil/format', self.ks[0]); self.fmt.setValue(self.ks.index(f) if f in self.ks else 0)
        self.fmt.valueChanged.connect(lambda v: QgsSettings().setValue('dgm_profil/format', self.ks[v]))
        self.gb, self.gg = QRadioButton('Bohrung'), QRadioButton('Geländeparallel') # Modus: Bohrung mit Bögen oder Kabel in Mindesttiefe entlang des Geländes
        (self.gg if QgsSettings().value('dgm_profil/gerade', False, type=bool) else self.gb).setChecked(True)
        self.gg.toggled.connect(self.modus)
        self.bohr = [self.xt, self.te, self.ta, self.ae, self.aa, self.hde, self.hda, self.bw, self.rm, btn3] # im Modus 'Geländeparallel' nicht benutzt

        # Eingaben in Gruppen nebeneinander (Querung | Tiefen und Winkel | Bohrung | Aktionen), Beschriftungen und Felder je Gruppe bündig
        top = QHBoxLayout()
        top.addWidget(self.group([('Linie', self.cl), ('DGM', self.cd), ('Objektbezeichnung', self.nm), (None, self.pair(btn4, btn5))]), 1)
        top.addWidget(self.group([[('Mindesttiefe', self.mt), ('Maximaltiefe', self.xt)], # Eintritt/Austritt jeweils nebeneinander
                                  [('Kabeltiefe Eintritt', self.te), ('Kabeltiefe Austritt', self.ta)],
                                  [('Eintrittswinkel', self.ae), ('Austrittswinkel', self.aa)]]), 2)
        top.addWidget(self.group([('Horiz. Distanz Eintritt', self.hde), ('Horiz. Distanz Austritt', self.hda), ('Objektbreite', self.bw), ('Biegeradius', self.rm)]), 1)
        top.addWidget(self.group([(None, self.pair(self.gb, self.gg)), (None, btn), (None, btn3), ('Format', self.pair(QLabel(self.ks[0]), self.fmt, QLabel(self.ks[-1]), fill=False)), (None, btn2)]), 1)
        self.fig = Figure()
        self.ax = self.fig.add_subplot(111)
        self.cv = Canvas(self.fig)
        self.info = QLabel('Maus über das Profil bewegen, Querungspunkt (Dreieck) mit gedrückter linker Maustaste verschieben')
        lay = QVBoxLayout(self)
        lay.addLayout(top); lay.addWidget(self.cv, 1); lay.addWidget(self.info)
        self.mk = QgsVertexMarker(iface.mapCanvas())
        self.mk.setColor(QColor('red')); self.mk.setIconSize(12); self.mk.hide()
        self.cv.mpl_connect('motion_notify_event', self.hover)
        self.cv.mpl_connect('button_press_event', self.press)
        self.cv.mpl_connect('button_release_event', self.release)
        self.rb = QgsRubberBand(iface.mapCanvas(), QgsWkbTypes.LineGeometry); self.rb.setColor(QColor('red')); self.rb.setWidth(2) # gezeichnete Linie
        self.tool = LinienWerkzeug(iface.mapCanvas(), self.gezeichnet); self.tool.deactivated.connect(self.show)
        self.finished.connect(lambda: (iface.mapCanvas().scene().removeItem(self.mk), iface.mapCanvas().scene().removeItem(self.rb), iface.mapCanvas().unsetMapTool(self.tool)))
        self.modus()

    def modus(self, *_):
        """Modus umschalten: nicht benutzte Eingaben ausgrauen, Profil neu zeichnen."""
        gd = self.gg.isChecked(); QgsSettings().setValue('dgm_profil/gerade', gd)
        for w in self.bohr: w.setEnabled(not gd)
        self.plot()

    def combo(self, key, filt, empty=''):
        c = QgsMapLayerComboBox(); c.setFilters(filt); c.setAllowEmptyLayer(bool(empty), empty) # vor setLayer, sonst geht die letzte Auswahl verloren
        l = QgsProject.instance().mapLayer(QgsSettings().value('dgm_profil/' + key, '')) # letzte Auswahl
        if l: c.setLayer(l)
        c.layerChanged.connect(lambda l, k=key: l and QgsSettings().setValue('dgm_profil/' + k, l.id())) # gezeichnete Linie nicht merken
        return c

    def spin(self, key, v, suf=' m', mx=1000, st=0.5, dec=2, special=None):
        s = QDoubleSpinBox(); s.setRange(0, mx); s.setSuffix(suf); s.setSingleStep(st); s.setDecimals(dec)
        if special: s.setSpecialValueText(special)
        s.setValue(QgsSettings().value('dgm_profil/' + key, v, type=float)) # letzter Wert
        s.valueChanged.connect(lambda x, k=key: QgsSettings().setValue('dgm_profil/' + k, x))
        s.valueChanged.connect(self.plot) # Parameter ändern -> Plot aktualisiert sich
        return s

    def group(self, rows):
        """Gruppe mit bündigen Zeilen: rows = [(Beschriftung, Widget), ...] oder [[(B, W), (B, W)], ...] für mehrere Felder nebeneinander; ohne Beschriftung über die ganze Breite."""
        g = QGroupBox(); grid = QGridLayout(g); n = 1
        for i, row in enumerate(rows):
            row = row if isinstance(row, list) else [row]; n = max(n, len(row))
            for j, (lab, w) in enumerate(row):
                if lab: grid.addWidget(QLabel(lab), i, 2 * j); grid.addWidget(w, i, 2 * j + 1)
                else: grid.addWidget(w, i, 2 * j, 1, 2)
        for j in range(n): grid.setColumnStretch(2 * j + 1, 1) # Felder füllen die Breite
        grid.setRowStretch(len(rows), 1) # Zeilen oben bündig
        return g

    def pair(self, *ws, fill=True):
        """Mehrere Widgets nebeneinander in einer Zeile (fill=False: linksbündig statt über die ganze Breite)."""
        w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0)
        for x in ws: h.addWidget(x)
        if not fill: h.addStretch()
        return w

    def run(self):
        line = self.cl.currentLayer()
        if self.line is None and self.gez: self.gez = (*self.gez[:2], self.s) # Querungspunkt der gezeichneten Linie merken
        if not line: # Auswahl 'gezeichnete Linie'
            if self.gez: self.line = self.fid = None; self.rb.setToGeometry(self.gez[0], None); self.profil(*self.gez)
            else: self.info.setText('Erst eine Linie zeichnen oder unter „Linie“ eine Ebene wählen.')
            return
        ft = next(iter(line.selectedFeatures() or line.getFeatures()), None) # markiertes Feature, sonst das erste
        if ft is None: self.info.setText(f'Ebene „{line.name()}“ enthält keine Linie.'); return
        self.line, self.fid = line, ft.id(); self.rb.reset(QgsWkbTypes.LineGeometry)
        try: s0 = float(ft[FELD])
        except (KeyError, TypeError, ValueError): s0 = None
        self.profil(ft.geometry(), line.crs(), s0)

    def zeichnen(self):
        self.hide(); iface.mapCanvas().setMapTool(self.tool) # Fenster kommt nach dem Zeichnen (oder Werkzeugwechsel) zurück

    def gezeichnet(self, g):
        iface.mapCanvas().unsetMapTool(self.tool)
        self.line = self.fid = None; self.rb.setToGeometry(g, None)
        self.gez = (g, iface.mapCanvas().mapSettings().destinationCrs(), None); self.cl.setCurrentIndex(0) # Auswahl auf 'gezeichnete Linie' (erster Eintrag; setLayer(None) würde die Auswahl nur leeren)
        self.profil(*self.gez)
        self.info.setText('Gezeichnete Linie: wird nicht gespeichert, außer mit „Linie speichern“.')

    def save_line(self):
        """Gezeichnete Linie mit Querungspunkt in GPKG im Projektordner speichern (Datei wird bei Bedarf angelegt)."""
        if self.geom is None or self.s is None: self.info.setText('Erst eine Linie zeichnen.'); return
        if self.line is not None: self.info.setText('Linie stammt schon aus einem Layer.'); return
        prj = QgsProject.instance()
        if not prj.homePath(): self.info.setText('Projekt zuerst speichern, die Datei wird im Projektordner angelegt.'); return
        pfad = os.path.join(prj.homePath(), GPKG)
        l = next((x for x in prj.mapLayers().values() if os.path.normcase(x.source().split('|')[0]) == os.path.normcase(pfad)), None)
        if l is None:
            if not os.path.exists(pfad): # Datei neu anlegen
                os.makedirs(os.path.dirname(pfad), exist_ok=True)
                tmp = QgsVectorLayer(f'LineString?crs={self.crs.authid()}&field={FELD}:double', 'querungen', 'memory')
                o = QgsVectorFileWriter.SaveVectorOptions(); o.driverName, o.layerName = 'GPKG', 'querungen'
                err = QgsVectorFileWriter.writeAsVectorFormatV3(tmp, pfad, prj.transformContext(), o)
                if err[0]: self.info.setText(f'{GPKG} konnte nicht angelegt werden: {err[1]}'); return
            l = QgsVectorLayer(pfad + '|layername=querungen', 'Querungen', 'ogr'); prj.addMapLayer(l)
        g = QgsGeometry(self.geom); g.transform(QgsCoordinateTransform(self.crs, l.crs(), prj))
        f = QgsFeature(l.fields()); f.setGeometry(g)
        if l.fields().indexOf(FELD) >= 0: f[FELD] = float(self.s)
        if l.isEditable(): ok = l.addFeature(f); fid = f.id()
        else: ok, fs = l.dataProvider().addFeatures([f]); fid = fs[0].id() if ok else None
        if not ok: self.info.setText(f'Linie konnte nicht in {GPKG} gespeichert werden.'); return
        l.triggerRepaint(); self.cl.setLayer(l); l.selectByIds([fid])
        self.line, self.fid, self.gez = l, fid, (*self.gez[:2], self.s); self.rb.reset(QgsWkbTypes.LineGeometry)
        self.info.setText(f'Linie in {GPKG} gespeichert (Ebene „Querungen“, markiert).')

    def profil(self, geom, crs, s0=None):
        """Profil entlang geom (Koordinatensystem crs) berechnen; s0 = gespeicherte Station des Querungspunkts oder None."""
        dgm = self.cd.currentLayer()
        if not dgm: self.info.setText('Kein DGM gewählt.'); return
        prj = QgsProject.instance()
        if crs.isGeographic(): # Linie in Grad: ins Koordinatensystem des DGM umrechnen, damit in Metern gerechnet wird
            if dgm.crs().isGeographic(): self.info.setText('Linie und DGM in Grad: bitte ein metrisches Koordinatensystem verwenden.'); return
            geom = QgsGeometry(geom); geom.transform(QgsCoordinateTransform(crs, dgm.crs(), prj)); crs = dgm.crs()
        step = 0.5 * dgm.rasterUnitsPerPixelX()
        tr = QgsCoordinateTransform(crs, dgm.crs(), prj)
        self.tm = QgsCoordinateTransform(crs, iface.mapCanvas().mapSettings().destinationCrs(), prj)
        self.crs, self.geom = crs, geom
        if self.geom.isMultipart():
            self.geom = self.geom.mergeLines()
        L = self.geom.length()
        ds = [i * step for i in range(int(L / step) + 1)]
        if L - ds[-1] > 1e-6: ds.append(L)

        # Himmelsrichtung der Profilenden: links = Linienanfang, rechts = Linienende
        az = self.geom.interpolate(0).asPoint().azimuth(self.geom.interpolate(L).asPoint())
        self.az = az
        N = ['N', 'NO', 'O', 'SO', 'S', 'SW', 'W', 'NW']
        self.dirs = [N[int((x + 22.5) % 360 // 45)] for x in (az + 180, az)]

        self.d, self.z = [], []
        for d in ds:
            z, ok = dgm.dataProvider().sample(tr.transform(self.geom.interpolate(d).asPoint()), 1)
            if ok:
                self.d.append(d); self.z.append(z)
        if len(self.d) < 2:
            self.info.setText('Linie liegt nicht (ausreichend) im DGM.')
            self.s = None; self.ax.clear(); self.cv.draw() # altes Profil nicht stehen lassen
            return

        # Querungspunkt: gespeicherte Station aus dem Attribut, sonst tiefster Tiefpunkt des Profils
        self.s = min(max(s0, self.d[0]), self.d[-1]) if s0 is not None else self.tiefpunkt()
        self.plot()

    def tiefpunkt(self):
        """Tiefster lokaler Tiefpunkt (Steigung 0) im Inneren der Linie. Fällt das Gelände nur zum Linienende hin ab, zählt das Ende nicht."""
        z = np.array(self.z); i = np.where((z[1:-1] <= z[:-2]) & (z[1:-1] <= z[2:]))[0] + 1 # lokale Minima
        if not len(i): return self.d[int(np.argmin(z))] # keine Mulde: globales Minimum
        i = i[z[i] == z[i].min()] # die tiefsten (bei flacher Sohle mehrere)
        return self.d[int(i[len(i) // 2])] # davon die mittlere

    def save_s(self, v):
        """Station des Querungspunkts als Attribut FELD im Linien-Feature speichern (NULL = automatisch)."""
        if self.line is None: self.err = 'gezeichnete Linie, erst mit „Linie speichern“ sichern'; return False
        l = self.line; dp = l.dataProvider(); i = dp.fields().indexOf(FELD)
        if i < 0: # Feld fehlt -> anlegen
            dp.addAttributes([QgsField(FELD, QVariant.Double)]); l.updateFields(); i = dp.fields().indexOf(FELD)
        if l.isEditable(): # Layer im Bearbeitungsmodus: Wert in die laufende Bearbeitung schreiben (wird mit dem Layer gespeichert)
            ok = l.changeAttributeValue(self.fid, l.fields().indexOf(FELD), v)
        else:
            ok = i >= 0 and dp.changeAttributeValues({self.fid: {i: v}})
            l.reload()
        self.err = '' if ok else ' '.join(dp.errors()[-1:]) or 'Datenquelle nicht beschreibbar'
        return ok

    def auto_s(self):
        if len(self.d) < 2: return
        self.s = self.tiefpunkt()
        ok = self.save_s(NULL)
        self.info.setText(f'Querungspunkt auf Tiefpunkt gesetzt (Abstand {self.s:.1f} m vom Linienanfang).' + ('' if ok or self.line is None else ' Attribut konnte nicht geleert werden.'))
        self.plot()

    def press(self, e):
        if e.inaxes != self.ax or e.button != 1 or self.s is None or self.gg.isChecked(): return # kein Querungspunkt im Modus 'Geländeparallel'
        self.drag = abs(e.x - self.ax.transData.transform((self.s, 0))[0]) < 10 # Klick bis 10 Pixel neben dem Querungspunkt

    def release(self, e):
        if not self.drag: return
        self.drag = False
        ok = self.save_s(self.s)
        self.info.setText(f'Querungspunkt bei {self.s:.1f} m vom Linienanfang' + (f' gespeichert (Attribut {FELD}).' if ok else f', konnte nicht im Linienlayer gespeichert werden: {self.err}'))

    def side(self, sign, h, w, zb, R, al, te):
        """Eine Seite der Bohrung: Start im Graben (Tiefe te unter Gelände), gerade Einfahrt (Winkel al),
        Bogen (Radius R) auf die Sohle zb.
        Abstand zum Objekt: mindestens h, sonst so groß, dass alles passt und die halbe Objektbreite auf Sohlenhöhe liegt.
        Ist die Tiefe für den vollen Winkel zu gering, wird der Winkel kleiner (reiner Bogen).
        Gibt (Abstand, horizontale Länge, Länge des geraden Stücks, verwendeter Winkel, Starthöhe) zurück."""
        for _ in range(100):
            z0 = float(np.interp(self.s + sign * h, self.d, self.z)) - te # Starthöhe der Bohrung
            D = max(z0 - zb, 0) # zu überwindende Tiefe
            dA = R * (1 - np.cos(al)) # Tiefe, die der Bogen beim Winkel al überwindet
            if D >= dA:
                xs = (D - dA) / np.tan(al); k = xs + R * np.sin(al); a = al
            else:
                xs = 0; k = np.sqrt(2 * R * D - D * D); a = np.arcsin(min(k / R, 1))
            if k + w / 2 <= h + 1e-6: break
            h = k + w / 2
        return h, k, xs, a, z0

    def plot(self, *_):
        if len(self.d) < 2: return
        ax = self.ax; ax.clear()
        nm = self.nm.text().strip(); obj = nm or 'Objekt'
        ax.plot(self.d, self.z, 'k-', label='Gelände (DGM)')
        warn = []
        gd = self.gg.isChecked()
        off = 0 if gd else self.s or 0 # x-Achse: 0 am Objekt, bei 'Geländeparallel' am Linienanfang
        if gd: # Geländeparallel: Kabel über die ganze Linie in Mindesttiefe, grobe Geländeformen folgen
            mt, d, z = self.mt.value(), np.array(self.d), np.array(self.z)
            n = max(int(GLAETTUNG / 2 / (d[-1] - d[0]) * (len(d) - 1)), 1); sw = np.lib.stride_tricks.sliding_window_view
            zk = sw(np.pad(sw(np.pad(z, n, 'edge'), 2 * n + 1).min(1), n, 'edge'), 2 * n + 1).mean(1) - mt # erst Minimum, dann Mittel über das Fenster: liegt überall mind. mt unter dem Gelände
            ax.plot(d, zk, 'b-', lw=2.5, label=f'Kabel/ Kabelsysteme (mind. {mt:.1f} m unter Gelände)')
            a, b, ze, zx, zb = d[0], d[-1], zk[0], zk[-1], zk.min()
            self.ab = (a, b)
            self.vars = {'objekt': obj, 'richtung': f'{self.dirs[0]} → {self.dirs[1]}', 'sohle_tiefe': f'{mt:.2f}', 'sohle_hoehe': f'{zb:.2f}',
                         'kabeltiefe_eintritt': f'{mt:.1f}', 'kabeltiefe_austritt': f'{mt:.1f}', 'bohrlaenge': f'{np.hypot(np.diff(d), np.diff(zk)).sum():.0f}',
                         **dict.fromkeys(('abstand_eintritt', 'abstand_austritt', 'biegeradius', 'winkel_eintritt', 'winkel_austritt'), '–')} # gibt es hier nicht
        elif self.s is not None:
            mt, xt, he, hx, w, R = self.mt.value(), self.xt.value(), self.hde.value(), self.hda.value(), self.bw.value(), max(self.rm.value(), 1)
            al, be = (np.radians(min(max(v.value(), 1), 60)) for v in (self.ae, self.aa))
            tea, teb = self.te.value(), self.ta.value()
            s = self.s
            zo = float(np.interp(s, self.d, self.z))
            zmin, zmax = zo - mt, zo - xt
            zb = max(zmin, zmax) # Sohle: Mindesttiefe, begrenzt durch Maximaltiefe
            ha, ka, xsa, ala, ze = self.side(-1, he, w, zb, R, al, tea)
            hb, kb, xsb, alb, zx = self.side(1, hx, w, zb, R, be, teb)
            a, b = s - ha, s + hb

            ax.plot([s], [zo], 'b^', ms=10, label=nm or 'Querungsobjekt')
            if not self.out: # Tiefengrenzen nur in der Vorschau, nicht im Layout
                ax.hlines(zmin, a, b, colors='g', linestyles='--', label=f'Mindesttiefe {mt:.1f} m')
                ax.hlines(zmax, a, b, colors='r', linestyles='--', label=f'Maximaltiefe {xt:.1f} m')
                ax.fill_between([a, b], zmin, zmax, color='orange', alpha=.2)
            for x, zz, n in ((a, ze, 'Eintritt'), (b, zx, 'Austritt')):
                ax.plot([x], [zz], 'bo')
                ax.annotate(f'{n}\n{x - s:+.1f} m / {zz:.2f} m', (x, zz), textcoords='offset points', xytext=(0, 10), ha='center')
            if self.out: # Layout: Tiefe der Sohle unter dem Objekt
                ax.annotate('', (s, zb), (s, zo), arrowprops=dict(arrowstyle='<->'))
                ax.text(s, (zo + zb) / 2, f' {zo - zb:.1f} m unter {obj}', va='center')
            else:
                for zt, t, ox in ((zmin, mt, 0), (zmax, xt, .15 * hx)):
                    ax.annotate('', (s + ox, zt), (s + ox, zo), arrowprops=dict(arrowstyle='<->'))
                    ax.text(s + ox, (zo + zt) / 2, f' {t:.1f} m', va='center')

            # Kabel im Graben außerhalb der Bohrung: horizontal ab Eintritt bzw. Austritt
            d, z = np.array(self.d), np.array(self.z)
            ax.plot([min(d[0], a), a], [ze, ze], 'b--', lw=1.5) # horizontal ab Eintritt
            ax.plot([b, max(d[-1], b)], [zx, zx], 'b--', lw=1.5) # horizontal ab Austritt

            # Bohrung: Eintritt -> gerade -> Bogen -> horizontal -> Bogen -> gerade -> Austritt
            sides = ((a, 1, ka, xsa, ala, ze), (b, -1, kb, xsb, alb, zx))
            def zf(x):
                x = np.asarray(x, float); z = np.full(x.shape, zb)
                for x0, sg, k, xs, ang, zg in sides:
                    u = (x - x0) * sg # Abstand vom Ein-/Austritt
                    arc = zb + R - np.sqrt(np.maximum(R * R - (k - u) ** 2, 0))
                    z = np.where((u >= 0) & (u < k), np.where(u < xs, zg - u * np.tan(ang), arc), z)
                return z
            xb = np.linspace(a, b, 400)
            deg = np.degrees
            ax.plot(xb, zf(xb), 'b-', lw=2.5, label='Bohrung')
            if not self.out:
                ax.annotate(f'Sohle {zb:.2f} m,\n({zo - zb:.1f} m unter {obj})', (s, zb),
                            textcoords='offset points', xytext=(0, -35), ha='center')

            self.ab = (a, b)
            bl = np.hypot(np.diff(xb), np.diff(zf(xb))).sum() # Bohrlänge
            self.vars = {'objekt': obj, 'richtung': f'{self.dirs[0]} → {self.dirs[1]}', 'sohle_tiefe': f'{zo - zb:.2f}', 'sohle_hoehe': f'{zb:.2f}',
                         'abstand_eintritt': f'{ha:.1f}', 'abstand_austritt': f'{hb:.1f}', 'kabeltiefe_eintritt': f'{tea:.1f}', 'kabeltiefe_austritt': f'{teb:.1f}',
                         'biegeradius': f'{R:.0f}', 'winkel_eintritt': f'{deg(ala):.0f}', 'winkel_austritt': f'{deg(alb):.0f}', 'bohrlaenge': f'{bl:.0f}'} # Layout-Variablen ohne Einheit

            if ha > he + 1e-6 or hb > hx + 1e-6: warn.append(f'Distanz angepasst: Eintritt {ha:.1f} m, Austritt {hb:.1f} m (Bogen braucht bei Biegeradius {R:.0f} m mehr Platz)')
            if ala < al - 1e-6: warn.append(f'Eintrittswinkel auf {deg(ala):.0f}° verkleinert (Biegeradius zu groß für diese Tiefe)')
            if alb < be - 1e-6: warn.append(f'Austrittswinkel auf {deg(alb):.0f}° verkleinert (Biegeradius zu groß für diese Tiefe)')
            if a < self.d[0] or b > self.d[-1]: warn.append('Eintritt/Austritt außerhalb der Linie')
            if mt > xt: warn.append('Mindesttiefe > Maximaltiefe')
            elif zmin < zmax: warn.append('Sohle durch Maximaltiefe begrenzt (Mindesttiefe nicht eingehalten)')
            if np.max(zf(np.array([s - w / 2, s, s + w / 2])) - zmin) > 1e-6: warn.append('Mindesttiefe am Objekt nicht eingehalten')
            if (zf(xb) > np.interp(xb, self.d, self.z) + .05).any(): warn.append('Bohrung liegt zwischen Ein- und Austritt über dem Gelände')
        if warn: ax.set_title('\n'.join(warn), color='r', fontsize=9)
        ax.set_xlabel(f'{self.abst()} (m)' if self.s is not None and not gd else 'Station (m)')
        ax.set_ylabel('Höhe (m)'); ax.grid(True)
        ax.legend(loc='lower right', fontsize=8 if self.out else None) # Legende im Diagramm unten rechts
        self.vl = ax.axvline(self.d[0], color='r', lw=.8)
        self.vl.set_visible(False)

        if self.out and self.s is not None:
            c, W, AH, S = self.view
            ax.set_xlim(c - W / 2, c + W / 2)
            m = (d >= c - W / 2) & (d <= c + W / 2)
            lo, hi = min(ze, zx, zb), z[m].max()
            self.sy = RUNDUNG * np.ceil((hi - lo) * 1.2 * 1000 / AH / RUNDUNG) # Höhenmaßstab 1:sy (10 % Rand oben und unten), aufgerundet
            zc, hh = (lo + hi) / 2, self.sy * AH / 2000; ax.set_ylim(zc - hh, zc + hh)

        # x-Achse: 0 am Objekt (Daten bleiben in Stationen), Himmelsrichtungen an den Enden
        lim = ax.get_xlim()
        ax.set_xticks(MaxNLocator(10, steps=[1, 2, 5, 10]).tick_values(lim[0] - off, lim[1] - off) + off)
        ax.set_xlim(lim)
        ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f'{round(x - off, 6):g}'))
        for x, al_, t in ((.01, 'left', f'← {self.dirs[0]}'), (.99, 'right', f'{self.dirs[1]} →')):
            ax.text(x, .98, t, transform=ax.transAxes, ha=al_, va='top', fontweight='bold', bbox=dict(fc='white', ec='none', alpha=.7))
        self.cv.draw()

    def export_layout(self):
        if self.s is None or len(self.d) < 2:
            self.info.setText('Erst ein Profil erstellen.'); return
        prj = QgsProject.instance()
        L = self.geom.length()
        a, b = max(self.ab[0], 0), min(self.ab[1], L)

        # Vorlage laden, Elemente über ihre Item ID holen
        n = VORLAGEN[self.ks[self.fmt.value()]] # Vorlage zum gewählten Format
        orte = [os.path.join(d, n) for d in (prj.homePath(), os.path.dirname(globals().get('__file__', '')))] # Projektordner, Plugin-Ordner
        vorlage = next((v for v in orte if os.path.isfile(v)), None)
        if not vorlage:
            self.info.setText('Vorlage nicht gefunden: ' + ' oder '.join(dict.fromkeys(orte))); return
        doc = QDomDocument(); doc.setContent(open(vorlage, encoding='utf-8').read())
        lay = QgsPrintLayout(prj); lay.loadFromTemplate(doc, QgsReadWriteContext()); lay.setName('Querprofil')
        m, p = lay.itemById('karte'), lay.itemById('profil')
        if m is None or p is None:
            self.info.setText("In der Vorlage fehlt ein Element mit der Item ID 'karte' oder 'profil'."); return

        # Karten-Ebenen: Bohrabschnitt und Ein-/Austritt (werden bei jedem Export ersetzt)
        for n in ('Bohrung', 'Eintritt/Austritt', 'Querungsobjekt', 'Querungspunkt', 'Querungslinie'):
            prj.removeMapLayers([l.id() for l in prj.mapLayersByName(n)])
        crs = self.crs.authid()
        lz = None # leyline, begehungsprotokoll, querungsprofil tool, 
        if self.line is None: # gezeichnete Linie als Ebene für Karte und Legende
            lz = QgsVectorLayer(f'LineString?crs={crs}', 'Querungslinie', 'memory'); ft = QgsFeature(); ft.setGeometry(self.geom); lz.dataProvider().addFeature(ft)
        lb = QgsVectorLayer(f'LineString?crs={crs}', 'Bohrung', 'memory')
        ft = QgsFeature(); ft.setGeometry(QgsGeometry(self.geom.constGet().curveSubstring(a, b)))
        lb.dataProvider().addFeature(ft)
        lb.renderer().symbol().setColor(QColor('red')); lb.renderer().symbol().setWidth(1.2)
        lp = QgsVectorLayer(f'Point?crs={crs}&field=name:string', 'Eintritt/Austritt', 'memory')
        fs = []
        for n, x in (('Eintritt', a), ('Austritt', b)):
            ft = QgsFeature(lp.fields()); ft.setGeometry(self.geom.interpolate(x)); ft.setAttributes([n]); fs.append(ft)
        lp.dataProvider().addFeatures(fs)
        lp.renderer().symbol().setColor(QColor('red'))
        st = QgsPalLayerSettings(); st.fieldName = 'name'
        lp.setLabeling(QgsVectorLayerSimpleLabeling(st)); lp.setLabelsEnabled(True)
        lq = None
        if not self.gg.isChecked(): # Querungsobjekt nur bei Bohrung
            lq = QgsVectorLayer(f'Point?crs={crs}&field=name:string', 'Querungsobjekt', 'memory')
            ft = QgsFeature(lq.fields()); ft.setGeometry(self.geom.interpolate(self.s)); ft.setAttributes([self.nm.text().strip()]); lq.dataProvider().addFeature(ft)
            lq.renderer().setSymbol(QgsMarkerSymbol.createSimple({'name': 'triangle', 'color': 'blue', 'size': '4'}))
            lq.setLabeling(QgsVectorLayerSimpleLabeling(st)); lq.setLabelsEnabled(True)
        prj.addMapLayers([x for x in (lz, lb, lp, lq) if x])

        # Größen aus der Vorlage (mm)
        MW, MH = lay.convertToLayoutUnits(m.sizeWithUnits()).width(), lay.convertToLayoutUnits(m.sizeWithUnits()).height()
        PW, PH = lay.convertToLayoutUnits(p.sizeWithUnits()).width(), lay.convertToLayoutUnits(p.sizeWithUnits()).height()
        ML, MR, MT, MB = 16, 6, 7, 12 # Ränder der Zeichenfläche im Profilbild (links Platz für die Höhenachse)
        AW, AH = PW - ML - MR, PH - MT - MB
        x0, x1 = min(self.d[0], self.ab[0]), max(self.d[-1], self.ab[1]) # Ausdehnung der Graphen (Station)
        S = RUNDUNG * np.ceil((x1 - x0) * 1000 / AW / RUNDUNG) # Profilmaßstab (Länge), aufgerundet
        W = AW * S / 1000 # dargestellte Breite in m: Graphen von Rand zu Rand, durch die Rundung minimal schmaler
        c = (x0 + x1) / 2 # Mitte des Profilausschnitts (Station)
        bb = self.geom.boundingBox(); m.setCrs(self.crs) # Karte im (metrischen) Koordinatensystem der Linie
        SK = next((x for x in (500, 1000, 2000, 2500, 5000, 10000, 25000, 50000, 100000)
                   if x >= max(bb.width() / MW, bb.height() / MH) * 1000 * UEBERSICHT_RAND), 250000) # Kartenmaßstab

        # Profil als SVG in der Größe des Elements 'profil' (im Projektordner unter 08_Layouts, ohne gespeichertes Projekt im Temp-Ordner)
        ordner = os.path.join(prj.homePath(), '08_Layouts') if prj.homePath() else tempfile.gettempdir(); os.makedirs(ordner, exist_ok=True)
        svg = os.path.join(ordner, f'querprofil_{datetime.now():%Y%m%d_%H%M%S}.svg') # eigene Datei je Export, ältere Layouts bleiben unverändert
        old = self.fig, self.ax
        self.fig = Figure(figsize=(PW / 25.4, PH / 25.4)); self.ax = self.fig.add_axes([ML / PW, MB / PH, AW / PW, AH / PH])
        self.out, self.view = True, (c, W, AH, S)
        self.plot(); self.fig.savefig(svg)
        self.fig, self.ax = old
        self.out = False
        self.plot()


        # Layout aus der Vorlage füllen (ersetzt ein vorhandenes Layout 'Querprofil')
        lm = prj.layoutManager()
        for o in lm.printLayouts():
            if o.name() == 'Querprofil': lm.removeLayout(o)
        lm.addLayout(lay)
        # 
        m.zoomToExtent(QgsRectangle.fromCenterAndSize(bb.center(), MW * SK / 1000, MH * SK / 1000)); m.setScale(SK)
        p.setPicturePath(svg)
        lg = lay.itemById('legende') # optional: Legende der Übersichtskarte mit den neu angelegten Ebenen füllen
        if lg is not None:
            lg.setAutoUpdateModel(False)
            g = lg.model().rootGroup(); g.clear()
            for l in (self.line or lz, lq, lp): l and g.addLayer(l) # Bohrungslinie nicht in der Legende
        for k, v in {**self.vars, 'massstab_profil': f'1:{S:.0f}', 'massstab_laengen': f'1:{S:.0f}', 'massstab_hoehen': f'1:{self.sy:.0f}', 'ueberhoehung': f'{S / self.sy:.1f}'}.items():
            QgsExpressionContextUtils.setLayoutVariable(lay, k, v) # in Textfeldern: [% @name %]
        QgsExpressionContextUtils.setLayoutVariable(lay, 'massstab_karte', f'1:{SK:g}') # in Textfeldern: [% @massstab_karte %]
        lay.refresh()

        iface.openLayoutDesigner(lay)
        self.info.setText("Layout 'Querprofil' erstellt." + ('' if b - a <= W else ' Achtung: Maßstab zu groß, die Bohrung passt nicht ins Profil.'))

    def abst(self):
        nm = self.nm.text().strip()
        return f'Abstand zu {nm}' if nm else 'Abstand zum Objekt'

    def hover(self, e):
        if e.inaxes != self.ax or not self.d: return
        if self.drag: # Querungspunkt verschieben
            self.s = float(min(max(e.xdata, self.d[0]), self.d[-1])); self.plot(); return # float(): numpy-Zahl würde als NULL gespeichert
        i = min(range(len(self.d)), key=lambda k: abs(self.d[k] - e.xdata))
        self.vl.set_xdata([self.d[i]] * 2); self.vl.set_visible(True)
        rel = f'{self.abst()} {self.d[i] - self.s:+.1f} m    ' if self.s is not None and not self.gg.isChecked() else ''
        self.info.setText(f'{rel}Station {self.d[i]:.1f} m    Höhe {self.z[i]:.2f} m')
        self.mk.setCenter(self.tm.transform(self.geom.interpolate(self.d[i]).asPoint())); self.mk.show()
        self.cv.draw_idle()